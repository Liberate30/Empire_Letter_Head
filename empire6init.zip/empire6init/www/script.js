const stamp = document.getElementById("stamp");

function takeShot() {
  if (window.confirm("Share Screenshot?") == true) {
    html2canvas(document.getElementById("output-container")).then(
      async (canvas) => {
        const url = canvas.toDataURL("image/png");
        encodeURI(url)
        const a = document.createElement("a");
        a.setAttribute("download", "imageName.png");
        a.setAttribute("href", url);
        a.click();
        const shareBtn = document.createElement("a");
        
        shareBtn.setAttribute('href', `https://web.whatsapp.com/://send?text=${url}`)
        shareBtn.setAttribute('target', '_blank')
        shareBtn.setAttribute('action', 'share/whatsapp/share')
        shareBtn.click();
      }
    );
  } else return;
}

stamp.addEventListener("click", takeShot);

blob
