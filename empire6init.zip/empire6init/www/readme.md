Version => 4 {
Some feature are screenshots,
download,
balance the date,
changed the text area word from change to charge,
removed uneccessary heights and widths

================
try {
            await navigator.share(shareImg)
          } catch (err) {
            alert(`Can not share screenshot. Error is: ${err.message}`);
          }
================
----------------
const shareImg = {
          title: "Receipt",
          text: title.value,
          url: url,
        };
}